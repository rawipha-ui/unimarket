UNIMARKET — คู่มือเริ่มต้น

ไฟล์ในชุดนี้
- index.html            หน้าเว็บไซต์
- Style.css             รูปแบบและการรองรับมือถือ
- app.js                การค้นหา/ลงขาย/รายการโปรด/ตะกร้า/สมาชิก
- config.js             ตั้งค่าการเชื่อมต่อ Supabase
- supabase-schema.sql   โครงสร้างฐานข้อมูลและสิทธิ์การเข้าถึง

1) ทดลองเปิดเว็บ
อัปโหลดไฟล์ทั้งหมดไปไว้ใน GitHub repository เดียวกัน (โฟลเดอร์หลัก)
เปิด Settings > Pages > Deploy from a branch > main > /(root) > Save
รอ GitHub Pages เผยแพร่ แล้วเปิด URL ของเว็บไซต์
ถ้ายังไม่ตั้งค่า Supabase เว็บไซต์จะแสดงสินค้าตัวอย่าง และบันทึกประกาศใหม่ไว้ในเบราว์เซอร์เครื่องนั้น

2) เปิดใช้ฐานข้อมูลและสมาชิกออนไลน์
- สร้างโปรเจกต์ที่ https://supabase.com
- เข้า SQL Editor แล้วรันเนื้อหาไฟล์ supabase-schema.sql
- ไปที่ Project Settings > API คัดลอก Project URL และ anon/public key
- ใส่สองค่านี้ใน config.js ที่ SUPABASE_URL และ SUPABASE_ANON_KEY
- อัปโหลด config.js ที่แก้แล้วขึ้น GitHub
- ใน Supabase Authentication > URL Configuration ตั้ง Site URL เป็น URL GitHub Pages ของคุณ
  และเพิ่ม URL เว็บไซต์ใน Redirect URLs (ถ้ามีการใช้งานยืนยันอีเมล)

ข้อควรทราบ
- ใช้ได้เฉพาะ anon/public key ในหน้าเว็บ ห้ามนำ service_role key มาใส่
- ระบบตะกร้าในชุดนี้เป็นรายการบันทึกความสนใจ ไม่ได้ตัดเงินหรือสร้างคำสั่งซื้อ
- ผู้ซื้อและผู้ขายต้องติดต่อและตกลงวิธีชำระเงิน/รับสินค้าโดยตรง
- โหมดทดลองเก็บประกาศใน localStorage ของเบราว์เซอร์ ไม่ได้แชร์ข้ามเครื่อง
- รูปภาพใช้ลิงก์รูปภาพสาธารณะ (https) ไม่ได้อัปโหลดไฟล์เข้าคลัง
