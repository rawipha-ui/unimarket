-- UniMarket database schema for Supabase
-- Run this script in Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 90),
  category text not null check (category in ('เสื้อผ้า','ไอที','หนังสือ','อาหาร','ของใช้','อื่นๆ')),
  price numeric(12,2) not null check (price >= 0),
  description text default '',
  emoji text default '🛍️',
  image_url text,
  seller_name text not null,
  contact text not null,
  status text not null default 'active' check (status in ('active','sold','hidden')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_status_created_idx
on public.products(status, created_at desc);

alter table public.products enable row level security;

drop policy if exists "Anyone can view active products" on public.products;
create policy "Anyone can view active products"
on public.products for select
using (status = 'active' or auth.uid() = user_id);

drop policy if exists "Authenticated users can insert own products" on public.products;
create policy "Authenticated users can insert own products"
on public.products for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can update own products" on public.products;
create policy "Users can update own products"
on public.products for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete own products" on public.products;
create policy "Users can delete own products"
on public.products for delete to authenticated
using (auth.uid() = user_id);

-- Optional updated_at trigger
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists products_updated_at on public.products;
create trigger products_updated_at
before update on public.products
for each row execute function public.set_updated_at();
