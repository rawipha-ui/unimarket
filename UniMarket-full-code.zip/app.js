(() => {
"use strict";
const $ = (s) => document.querySelector(s);
const demoProducts = [
 {id:"d1",name:"หูฟังไร้สายสีครีม",category:"ไอที",price:259,description:"เสียงดี ใช้งานปกติ มีเคสและสายชาร์จ",emoji:"🎧",seller_name:"Mint",contact:"@mintshop",created_at:"2026-11-10"},
 {id:"d2",name:"เสื้อไหมพรมวินเทจ",category:"เสื้อผ้า",price:189,description:"ใส่สบาย สภาพดี ไซซ์ M",emoji:"🧥",seller_name:"Nana",contact:"@nana",created_at:"2026-11-09"},
 {id:"d3",name:"หนังสือเตรียมสอบ",category:"หนังสือ",price:120,description:"อ่านเข้าใจง่าย มีจดโน้ตเล็กน้อย",emoji:"📚",seller_name:"Bookie",contact:"@bookie",created_at:"2026-11-08"},
 {id:"d4",name:"เค้กช็อกโกแลต",category:"อาหาร",price:45,description:"เนื้อนุ่ม เข้มข้น ทำสดใหม่ตามออเดอร์",emoji:"🍰",seller_name:"Bake Day",contact:"@bakeday",created_at:"2026-11-07"},
 {id:"d5",name:"โคมไฟตั้งโต๊ะ",category:"ของใช้",price:199,description:"แสงถนอมสายตา เหมาะกับอ่านหนังสือ",emoji:"💡",seller_name:"Ploy",contact:"@ploy",created_at:"2026-11-06"},
 {id:"d6",name:"กระเป๋าผ้าแคนวาส",category:"เสื้อผ้า",price:99,description:"ผ้าหนา จุของได้เยอะ มินิมอล",emoji:"👜",seller_name:"June",contact:"@june",created_at:"2026-11-05"},
 {id:"d7",name:"กล้องฟิล์มมือสอง",category:"ไอที",price:790,description:"ใช้งานได้ มีร่องรอยตามการใช้งาน",emoji:"📷",seller_name:"Filmclub",contact:"@filmclub",created_at:"2026-11-04"},
 {id:"d8",name:"ตุ๊กตานุ่มนิ่ม",category:"ของใช้",price:150,description:"ซักสะอาดแล้ว นุ่มมาก เหมาะเป็นของขวัญ",emoji:"🧸",seller_name:"Mew",contact:"@mew",created_at:"2026-11-03"}
];
let products=[], user=null, selectedCategory="ทั้งหมด", favorites=JSON.parse(localStorage.getItem("um_favorites")||"[]"), cart=JSON.parse(localStorage.getItem("um_cart")||"[]"), showFavorites=false, editingId=null, sb=null, authMode="login";
const cfg=window.UNIMARKET_CONFIG||{};
const online=Boolean(cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&window.supabase);
if(online){sb=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);}
const escapeHTML=(v="")=>String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money=n=>Number(n).toLocaleString("th-TH");
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2600)}
function persist(){localStorage.setItem("um_favorites",JSON.stringify(favorites));localStorage.setItem("um_cart",JSON.stringify(cart));$("#favoriteCount").textContent=favorites.length;$("#cartCount").textContent=cart.length}
function localProducts(){try{return JSON.parse(localStorage.getItem("um_products")||"[]")}catch{return []}}
function saveLocal(){localStorage.setItem("um_products",JSON.stringify(products))}
async function loadProducts(){
 if(sb){const {data,error}=await sb.from("products").select("*").eq("status","active").order("created_at",{ascending:false});if(error){console.error(error);toast("โหลดข้อมูลออนไลน์ไม่สำเร็จ กำลังใช้ข้อมูลทดลอง");products=[...localProducts(),...demoProducts]}else products=data||[]}
 else products=[...localProducts(),...demoProducts];
 $("#statProducts").textContent=products.length;renderProducts();
}
function filteredProducts(){
 let list=[...products],q=$("#searchInput").value.trim().toLowerCase();
 if(showFavorites)list=list.filter(p=>favorites.includes(String(p.id)));
 if(selectedCategory!=="ทั้งหมด")list=list.filter(p=>p.category===selectedCategory);
 if(q)list=list.filter(p=>[p.name,p.description,p.category,p.seller_name].join(" ").toLowerCase().includes(q));
 const sort=$("#sortSelect").value;
 if(sort==="price-low")list.sort((a,b)=>a.price-b.price);
 else if(sort==="price-high")list.sort((a,b)=>b.price-a.price);
 else list.sort((a,b)=>new Date(b.created_at||0)-new Date(a.created_at||0));
 return list;
}
function renderProducts(){
 const list=filteredProducts();$("#resultsLabel").textContent=`พบ ${list.length} รายการ${showFavorites?" ในรายการโปรด":""}`;
 $("#statProducts").textContent=products.length;$("#emptyState").classList.toggle("hidden",list.length>0);
 $("#productGrid").innerHTML=list.map(p=>{
 const id=String(p.id),fav=favorites.includes(id),img=p.image_url?`<img src="${escapeHTML(p.image_url)}" alt="${escapeHTML(p.name)}" loading="lazy">`:`<span class="product-emoji">${escapeHTML(p.emoji||"🛍️")}</span>`;
 return `<article class="product-card"><div class="product-image">${img}<span class="product-tag">${escapeHTML(p.category)}</span><button class="favorite-btn ${fav?"active":""}" data-fav="${escapeHTML(id)}" aria-label="เพิ่มรายการโปรด">${fav?"♥":"♡"}</button></div><div class="product-info"><h3>${escapeHTML(p.name)}</h3><div class="product-description">${escapeHTML(p.description||"ไม่มีรายละเอียดสินค้า")}</div><div class="product-bottom"><div class="price">฿${money(p.price)} <small>บาท</small></div><span class="seller-name">โดย ${escapeHTML(p.seller_name||"ผู้ขาย")}</span></div><div class="card-actions"><button data-detail="${escapeHTML(id)}">ดูรายละเอียด</button><button data-cart="${escapeHTML(id)}">＋ ใส่ตะกร้า</button></div></div></article>`;
 }).join("");
}
function findProduct(id){return products.find(p=>String(p.id)===String(id))}
function openModal(html){$("#modalContent").innerHTML=html;$("#modalBackdrop").classList.remove("hidden")}
function closeModal(){$("#modalBackdrop").classList.add("hidden")}
function detail(id){
 const p=findProduct(id);if(!p)return;
 const img=p.image_url?`<img src="${escapeHTML(p.image_url)}" alt="${escapeHTML(p.name)}">`:escapeHTML(p.emoji||"🛍️");
 openModal(`<div class="detail-image">${img}</div><span class="eyebrow">${escapeHTML(p.category)}</span><h2>${escapeHTML(p.name)}</h2><div class="detail-price">฿${money(p.price)}</div><p class="detail-copy">${escapeHTML(p.description||"ไม่มีรายละเอียด")}</p><div class="detail-meta">ผู้ขาย: ${escapeHTML(p.seller_name||"ไม่ระบุ")} · ลงขาย ${p.created_at?new Date(p.created_at).toLocaleDateString("th-TH"):""}</div><div class="detail-meta">ช่องทางติดต่อ: ${escapeHTML(p.contact||"กรุณาติดต่อผ่านผู้ขาย")}</div><button class="btn btn-primary form-submit" data-cart="${escapeHTML(String(p.id))}">เพิ่มลงตะกร้า</button>${user&&p.user_id===user.id?`<button class="btn btn-outline form-submit" data-edit="${escapeHTML(String(p.id))}">แก้ไขประกาศนี้</button>`:""}<p class="detail-meta">หมายเหตุ: โปรดตรวจสอบสินค้าและตกลงการชำระเงินกับผู้ขายโดยตรง</p>`);
}
function requireLogin(){if(!user){authForm();toast("กรุณาเข้าสู่ระบบก่อนลงขายสินค้า");return false}return true}
function sellForm(p=null){
 if(!requireLogin())return;editingId=p?String(p.id):null;
 openModal(`<h2 id="modalTitle">${p?"แก้ไขประกาศ":"ลงขายสินค้า"}</h2><p class="sub">กรอกรายละเอียดให้ครบ เพื่อให้ผู้ซื้อรู้จักสินค้าของคุณ</p>
 <form id="productForm">
 <label class="form-field"><span>ชื่อสินค้า *</span><input name="name" required maxlength="90" value="${escapeHTML(p?.name||"")}" placeholder="เช่น หูฟังไร้สาย"></label>
 <div class="form-grid"><label class="form-field"><span>ราคา (บาท) *</span><input name="price" type="number" min="0" step="1" required value="${p?.price??""}" placeholder="ราคา"></label><label class="form-field"><span>หมวดหมู่ *</span><select name="category" required>${["เสื้อผ้า","ไอที","หนังสือ","อาหาร","ของใช้","อื่นๆ"].map(c=>`<option ${p?.category===c?"selected":""}>${c}</option>`).join("")}</select></label></div>
 <label class="form-field"><span>รายละเอียดสินค้า</span><textarea name="description" maxlength="500" placeholder="สภาพสินค้า จุดเด่น หรือข้อมูลเพิ่มเติม">${escapeHTML(p?.description||"")}</textarea></label>
 <div class="form-grid"><label class="form-field"><span>อีโมจิแทนสินค้า</span><input name="emoji" maxlength="8" value="${escapeHTML(p?.emoji||"🛍️")}" placeholder="🛍️"></label><label class="form-field"><span>ลิงก์รูปภาพ (ถ้ามี)</span><input name="image_url" type="url" value="${escapeHTML(p?.image_url||"")}" placeholder="https://..."></label></div>
 <label class="form-field"><span>ชื่อผู้ขาย</span><input name="seller_name" maxlength="60" value="${escapeHTML(p?.seller_name||user.email?.split("@")[0]||"")}" required></label>
 <label class="form-field"><span>ช่องทางติดต่อ *</span><input name="contact" maxlength="100" value="${escapeHTML(p?.contact||"")}" required placeholder="เช่น LINE ID หรือเบอร์โทร"></label>
 <button class="btn btn-primary form-submit" type="submit">${p?"บันทึกการแก้ไข":"ลงประกาศขาย"}</button>
 ${p?`<button class="btn btn-outline form-submit" type="button" id="deleteProductBtn">ลบประกาศนี้</button>`:""}</form>`);
 $("#productForm").addEventListener("submit",submitProduct);
 if(p)$("#deleteProductBtn").addEventListener("click",()=>deleteProduct(p.id));
}
async function submitProduct(e){
 e.preventDefault();const f=new FormData(e.currentTarget),payload=Object.fromEntries(f.entries());
 payload.price=Number(payload.price);payload.user_id=user.id;payload.status="active";
 if(!payload.name||!Number.isFinite(payload.price)||payload.price<0||!payload.contact){toast("กรุณาตรวจสอบข้อมูลให้ครบ");return}
 if(sb){
  const result=editingId?await sb.from("products").update(payload).eq("id",editingId).eq("user_id",user.id):await sb.from("products").insert(payload);
  if(result.error){toast("บันทึกไม่สำเร็จ: "+result.error.message);return}
 }else{
  if(editingId){products=products.map(p=>String(p.id)===editingId?{...p,...payload}:p)}
  else products.unshift({id:"local-"+Date.now(),...payload,created_at:new Date().toISOString()});
  saveLocal();
 }
 closeModal();toast(editingId?"แก้ไขประกาศแล้ว":"ลงขายสินค้าสำเร็จ");await loadProducts();
}
async function deleteProduct(id){
 if(!confirm("ยืนยันลบประกาศสินค้านี้หรือไม่?"))return;
 if(sb){const {error}=await sb.from("products").delete().eq("id",id).eq("user_id",user.id);if(error){toast("ลบไม่สำเร็จ: "+error.message);return}}
 else{products=products.filter(p=>String(p.id)!==String(id));saveLocal()}
 closeModal();toast("ลบประกาศแล้ว");await loadProducts();
}
function authForm(){
 authMode="login";
 const draw=()=>openModal(`<h2>${authMode==="login"?"ยินดีต้อนรับกลับ 👋":"สร้างบัญชี UniMarket ✨"}</h2><p class="sub">${online?"เข้าสู่ระบบเพื่อจัดการประกาศขายของคุณ":"โหมดทดลอง: ระบบสมาชิกจะใช้งานเมื่อเชื่อมต่อ Supabase"}</p><form id="authForm"><label class="form-field"><span>อีเมล</span><input name="email" type="email" required placeholder="you@example.com"></label><label class="form-field"><span>รหัสผ่าน</span><input name="password" type="password" minlength="6" required placeholder="อย่างน้อย 6 ตัวอักษร"></label><button class="btn btn-primary form-submit" type="submit">${authMode==="login"?"เข้าสู่ระบบ":"สมัครสมาชิก"}</button></form><div class="switch-auth">${authMode==="login"?"ยังไม่มีบัญชี?":"มีบัญชีอยู่แล้ว?"} <button id="switchAuth">${authMode==="login"?"สมัครสมาชิก":"เข้าสู่ระบบ"}</button></div>`);
  $("#authForm").addEventListener("submit",async e=>{e.preventDefault();if(!sb){toast("กรุณาตั้งค่า Supabase ใน config.js เพื่อเปิดระบบสมาชิก");return}
   const fd=new FormData(e.currentTarget),email=fd.get("email"),password=fd.get("password");
   const r=authMode==="login"?await sb.auth.signInWithPassword({email,password}):await sb.auth.signUp({email,password});
   if(r.error){toast(r.error.message);return}
   if(authMode==="signup"&&!r.data.session){toast("สมัครสำเร็จ กรุณายืนยันอีเมลก่อนเข้าสู่ระบบ");closeModal();return}
   user=r.data.user;closeModal();updateAuth();toast(authMode==="login"?"เข้าสู่ระบบแล้ว":"สมัครสมาชิกสำเร็จ");
  });
  $("#switchAuth").addEventListener("click",()=>{authMode=authMode==="login"?"signup":"login";draw()});
 };draw();
}
function updateAuth(){$("#loginBtn").textContent=user?"ออกจากระบบ":"เข้าสู่ระบบ";$("#sellBtn").textContent=user?"＋ ลงขายสินค้า":"＋ ลงขายสินค้า"}
async function logout(){if(sb)await sb.auth.signOut();user=null;updateAuth();toast("ออกจากระบบแล้ว")}
function addCart(id){const p=findProduct(id);if(!p)return;cart.push(String(id));persist();toast("เพิ่มลงตะกร้าแล้ว")}
function showCart(){const items=cart.map(id=>findProduct(id)).filter(Boolean);openModal(`<h2>ตะกร้าสินค้า 🛒</h2><p class="sub">รายการที่คุณสนใจ</p>${items.length?items.map(p=>`<div class="cart-line" style="display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #eee;font-size:12px"><span>${escapeHTML(p.emoji||"🛍️")} ${escapeHTML(p.name)}</span><b>฿${money(p.price)}</b></div>`).join("")+`<h3 style="text-align:right">รวม ฿${money(items.reduce((s,p)=>s+Number(p.price),0))}</h3><p class="detail-meta">ตะกร้านี้เป็นรายการบันทึกความสนใจ ยังไม่ใช่ระบบชำระเงิน กรุณาติดต่อผู้ขายเพื่อยืนยันการสั่งซื้อ</p><button class="btn btn-outline form-submit" id="clearCart">ล้างตะกร้า</button>`:`<p class="detail-copy">ยังไม่มีสินค้าในตะกร้า ลองเลือกของที่ชอบดูก่อนนะ</p>`}`);
 if($("#clearCart"))$("#clearCart").addEventListener("click",()=>{cart=[];persist();showCart()});
}
function toggleFavorite(id){favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];persist();renderProducts()}
function setup(){
 $("#year").textContent=new Date().getFullYear();persist();
 $("#searchInput").addEventListener("input",renderProducts);$("#sortSelect").addEventListener("change",renderProducts);
 $("#categoryRow").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;selectedCategory=b.dataset.category;showFavorites=false;document.querySelectorAll(".category-chip").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
 $("#clearFilters").addEventListener("click",()=>{$("#searchInput").value="";selectedCategory="ทั้งหมด";showFavorites=false;document.querySelectorAll(".category-chip").forEach((x,i)=>x.classList.toggle("active",i===0));renderProducts()});
 $("#resetSearch").addEventListener("click",()=>$("#clearFilters").click());
 $("#productGrid").addEventListener("click",e=>{const f=e.target.closest("[data-fav]"),d=e.target.closest("[data-detail]"),c=e.target.closest("[data-cart]");if(f)toggleFavorite(f.dataset.fav);if(d)detail(d.dataset.detail);if(c)addCart(c.dataset.cart)});
 $("#modalContent").addEventListener("click",e=>{const c=e.target.closest("[data-cart]"),ed=e.target.closest("[data-edit]");if(c)addCart(c.dataset.cart);if(ed)sellForm(findProduct(ed.dataset.edit))});
 $("#modalClose").addEventListener("click",closeModal);$("#modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal()});
 $("#loginBtn").addEventListener("click",()=>user?logout():authForm());
 ["sellBtn","heroSellBtn","bannerSellBtn"].forEach(id=>$("#"+id).addEventListener("click",()=>sellForm()));
 $("#cartBtn").addEventListener("click",showCart);
 $("#favoritesBtn").addEventListener("click",()=>{showFavorites=!showFavorites;selectedCategory="ทั้งหมด";document.querySelectorAll(".category-chip").forEach((x,i)=>x.classList.toggle("active",i===0));renderProducts();$("#products").scrollIntoView({behavior:"smooth"})});
 if(sb){sb.auth.getSession().then(({data})=>{user=data.session?.user||null;updateAuth()});sb.auth.onAuthStateChange((_event,session)=>{user=session?.user||null;updateAuth()})}
}
document.addEventListener("DOMContentLoaded",()=>{setup();loadProducts();if(!online)console.info("UniMarket demo mode: configure Supabase in config.js for shared online data and accounts.")});
})();