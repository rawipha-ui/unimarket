/*
  ตั้งค่า Supabase เมื่อพร้อมใช้งาน:
  1) สร้างโปรเจกต์ที่ https://supabase.com
  2) ไปที่ Project Settings > API
  3) ใส่ Project URL และ anon/public key ด้านล่าง
  ห้ามใส่ service_role key ในไฟล์หน้าเว็บเด็ดขาด
*/
window.UNIMARKET_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
